package com.clark.bassplayer

import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Mantém a música tocando em segundo plano, com notificação e controles. */
class PlayerService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        Engine.init(applicationContext)
        session = MediaSession.Builder(this, Engine.player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session

    override fun onDestroy() {
        session?.release(); session = null
        super.onDestroy()
    }
}
