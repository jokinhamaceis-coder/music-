package com.clark.bassplayer

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Engine.init(applicationContext)
        startService(Intent(this, PlayerService::class.java))
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF00E5FF), background = Color(0xFF0B0F14), surface = Color(0xFF0B0F14))) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

fun loadTracks(ctx: Context): List<MediaItem> = try {
    val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val proj = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
    val out = mutableListOf<MediaItem>()
    ctx.contentResolver.query(uri, proj, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
        "${MediaStore.Audio.Media.TITLE} ASC")?.use { c ->
        while (c.moveToNext()) {
            val id = c.getLong(0)
            out += MediaItem.Builder().setMediaId(id.toString())
                .setUri(ContentUris.withAppendedId(uri, id))
                .setMediaMetadata(MediaMetadata.Builder().setTitle(c.getString(1)).setArtist(c.getString(2)).build())
                .build()
        }
    }
    out
} catch (e: Exception) { emptyList() }

@Composable
fun App() {
    val ctx = LocalContext.current
    var tracks by remember { mutableStateOf(listOf<MediaItem>()) }
    var ready by remember { mutableIntStateOf(0) }
    var tab by remember { mutableIntStateOf(0) }
    var title by remember { mutableStateOf(Engine.player.currentMediaItem?.mediaMetadata?.title?.toString() ?: "Escolha uma música") }
    var playing by remember { mutableStateOf(Engine.player.isPlaying) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(1L) }
    val prefs = remember { ctx.getSharedPreferences("bp", Context.MODE_PRIVATE) }
    var bgUri by remember { mutableStateOf(prefs.getString("bg", null)) }
    var bgAlpha by remember { mutableFloatStateOf(prefs.getFloat("a", 0.5f)) }
    var bg by remember { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(bgUri) {
        bg = bgUri?.let { u ->
            withContext(Dispatchers.IO) {
                try {
                    val o = BitmapFactory.Options().apply { inSampleSize = 4 }
                    ctx.contentResolver.openInputStream(Uri.parse(u))?.use { BitmapFactory.decodeStream(it, null, o)?.asImageBitmap() }
                } catch (e: Exception) { null }
            }
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            try { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            prefs.edit().putString("bg", u.toString()).apply(); bgUri = u.toString()
        }
    }

    val perms = if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { ready++ }
    LaunchedEffect(Unit) { launcher.launch(perms) }
    LaunchedEffect(ready) { tracks = withContext(Dispatchers.IO) { loadTracks(ctx) } }

    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                title = mediaItem?.mediaMetadata?.title?.toString() ?: ""
            }
        }
        Engine.player.addListener(l)
        onDispose { Engine.player.removeListener(l) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            pos = Engine.player.currentPosition
            dur = Engine.player.duration.coerceAtLeast(1L)
            delay(500)
        }
    }

    Box(Modifier.fillMaxSize()) {
    val b = bg
    if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = bgAlpha)
    else Hero(Modifier.fillMaxSize())
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xCC0B0F14), Color(0x880B0F14), Color(0xEE0B0F14)))))
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TabRow(selectedTabIndex = tab, containerColor = Color.Transparent) {
            Tab(tab == 0, { tab = 0 }, text = { Text("Músicas") })
            Tab(tab == 1, { tab = 1 }, text = { Text("Equalizador") })
            Tab(tab == 2, { tab = 2 }, text = { Text("Visual") })
        }
        Box(Modifier.weight(1f)) {
            if (tab == 0) {
                if (tracks.isEmpty()) Text("Nenhuma música encontrada (verifique a permissão).", Modifier.padding(16.dp))
                LazyColumn {
                    itemsIndexed(tracks) { i, t ->
                        Column(Modifier.fillMaxWidth().clickable {
                            Engine.player.setMediaItems(tracks, i, 0L)
                            Engine.player.prepare(); Engine.player.play()
                        }.padding(horizontal = 16.dp, vertical = 10.dp)) {
                            Text(t.mediaMetadata.title?.toString() ?: "?", maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(t.mediaMetadata.artist?.toString() ?: "", maxLines = 1,
                                style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                    }
                }
            } else if (tab == 1) Effects()
            else Visual(bgAlpha, { bgAlpha = it; prefs.edit().putFloat("a", it).apply() },
                { picker.launch(arrayOf("image/*")) },
                { prefs.edit().remove("bg").apply(); bgUri = null })
        }
        Column(Modifier.fillMaxWidth().padding(12.dp).navigationBarsPadding()) {
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Slider(pos.toFloat(), { Engine.player.seekTo(it.toLong()) }, valueRange = 0f..dur.toFloat())
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
                Button({ Engine.player.seekToPrevious() }) { Text("⏮") }
                Button({ if (playing) Engine.player.pause() else Engine.player.play() }) { Text(if (playing) "⏸" else "▶") }
                Button({ Engine.player.seekToNext() }) { Text("⏭") }
            }
        }
    }
    }
}

@Composable
fun Effects() {
    var ver by remember { mutableIntStateOf(0) }
    key(ver) {
        var bass by remember { mutableFloatStateOf(Engine.bass.toFloat()) }
        var boost by remember { mutableFloatStateOf(Engine.boost.toFloat()) }
        var virt by remember { mutableFloatStateOf(Engine.virt.toFloat()) }
        Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState())) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ Engine.bassPreset(); ver++ }) { Text("Bass+") }
                OutlinedButton({ Engine.flat(); ver++ }) { Text("Zerar") }
            }
            Text("Graves (Bass Boost): ${(bass / 10).toInt()}%", Modifier.padding(top = 12.dp))
            Slider(bass, { bass = it; Engine.bass = it.toInt(); Engine.push() }, valueRange = 0f..1000f)
            Text("Volume extra: +${"%.1f".format(boost / 100f)} dB")
            Slider(boost, { boost = it; Engine.boost = it.toInt(); Engine.push() }, valueRange = 0f..1500f)
            Text("Som 3D (Virtualizer): ${(virt / 10).toInt()}%")
            Slider(virt, { virt = it; Engine.virt = it.toInt(); Engine.push() }, valueRange = 0f..1000f)
            Text("Equalizador", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.titleMedium)
            val lv = remember { mutableStateListOf(*Engine.levels.toTypedArray()) }
            lv.forEachIndexed { i, v ->
                val f = Engine.freqs.getOrElse(i) { 0 }
                Text(if (f >= 1000) "${f / 1000f} kHz" else "$f Hz")
                Slider(v.toFloat(), { lv[i] = it.toInt(); Engine.levels[i] = it.toInt(); Engine.push() },
                    valueRange = Engine.minLvl.toFloat()..Engine.maxLvl.toFloat())
            }
        }
    }
}

@Composable
fun Visual(alpha: Float, onAlpha: (Float) -> Unit, onPick: () -> Unit, onReset: () -> Unit) {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(onPick) { Text("Escolher personagem (imagem da galeria)") }
        OutlinedButton(onReset) { Text("Usar herói padrão") }
        Text("Visibilidade do personagem")
        Slider(alpha, onAlpha, valueRange = 0.1f..1f)
    }
}

/** Herói original (silhueta com capa) desenhado em código, usado como fundo padrão. */
@Composable
fun Hero(modifier: Modifier) = Canvas(modifier) {
    val w = size.width; val h = size.height; val cx = w / 2
    drawRect(Brush.verticalGradient(listOf(Color(0xFF0D2A6B), Color(0xFF0B0F14))))
    drawCircle(Color(0x33FFD600), w * 0.45f, Offset(cx, h * 0.36f))
    val cape = Path().apply {
        moveTo(cx - w * 0.12f, h * 0.31f); lineTo(cx + w * 0.12f, h * 0.31f)
        lineTo(cx + w * 0.42f, h * 0.74f); lineTo(cx - w * 0.42f, h * 0.74f); close()
    }
    drawPath(cape, Color(0xFFC62828))
    drawRoundRect(Color(0xFF1E4DB7), Offset(cx - w * 0.1f, h * 0.29f), Size(w * 0.2f, h * 0.3f), CornerRadius(w * 0.04f))
    drawCircle(Color(0xFFFFD600), w * 0.035f, Offset(cx, h * 0.38f))
    drawCircle(Color(0xFFF1C9A5), w * 0.06f, Offset(cx, h * 0.25f))
    drawRoundRect(Color(0xFF1E4DB7), Offset(cx - w * 0.09f, h * 0.58f), Size(w * 0.18f, h * 0.2f), CornerRadius(w * 0.03f))
}
