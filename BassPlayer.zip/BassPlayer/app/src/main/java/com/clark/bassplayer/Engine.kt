package com.clark.bassplayer

import android.content.Context
import android.media.audiofx.*
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

/** Player único + efeitos de áudio (EQ, bass boost, volume extra, 3D). */
object Engine {
    lateinit var player: ExoPlayer
    private var eq: Equalizer? = null
    private var bb: BassBoost? = null
    private var le: LoudnessEnhancer? = null
    private var vz: Virtualizer? = null

    var bass = 0      // 0..1000
    var boost = 0     // milibels, 0..1500
    var virt = 0      // 0..1000
    var levels = IntArray(5)
    var freqs = IntArray(5) { 60 }
    var minLvl = -1500
    var maxLvl = 1500

    fun init(c: Context) {
        if (::player.isInitialized) return
        player = ExoPlayer.Builder(c)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) = attach(audioSessionId)
        })
        attach(player.audioSessionId)
    }

    private fun attach(id: Int) {
        if (id == C.AUDIO_SESSION_ID_UNSET || id == 0) return
        listOf<AudioEffect?>(eq, bb, le, vz).forEach { try { it?.release() } catch (_: Exception) {} }
        try {
            eq = Equalizer(0, id).apply {
                enabled = true
                minLvl = bandLevelRange[0].toInt(); maxLvl = bandLevelRange[1].toInt()
                val n = numberOfBands.toInt()
                if (levels.size != n) levels = IntArray(n)
                freqs = IntArray(n) { getCenterFreq(it.toShort()) / 1000 }
            }
        } catch (_: Exception) {}
        try { bb = BassBoost(0, id).apply { enabled = true } } catch (_: Exception) {}
        try { le = LoudnessEnhancer(id).apply { enabled = true } } catch (_: Exception) {}
        try { vz = Virtualizer(0, id).apply { enabled = true } } catch (_: Exception) {}
        push()
    }

    fun push() {
        levels.forEachIndexed { i, l -> try { eq?.setBandLevel(i.toShort(), l.toShort()) } catch (_: Exception) {} }
        try { if (bb?.strengthSupported == true) bb?.setStrength(bass.toShort()) } catch (_: Exception) {}
        try { le?.setTargetGain(boost) } catch (_: Exception) {}
        try { if (vz?.strengthSupported == true) vz?.setStrength(virt.toShort()) } catch (_: Exception) {}
    }

    fun flat() { bass = 0; boost = 0; virt = 0; levels.fill(0); push() }

    fun bassPreset() {
        bass = 900
        for (i in levels.indices) levels[i] = when (i) { 0 -> maxLvl * 8 / 10; 1 -> maxLvl * 5 / 10; else -> 0 }
        push()
    }
}
